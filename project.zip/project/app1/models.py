from django.db import models

# Create your models here.
class Grades(models.Model):
    grade_name = models.CharField(max_length=20)
    grade_crate_data = models.DateTimeField()
    grade_gril_num   = models.IntegerField()
    grade_boy_num   = models.IntegerField()
    grade_isDelete   = models.BooleanField(default=False)


class Students(models.Model):
    student_name = models.CharField(max_length=20)
    student_gender = models.BooleanField(default=True)
    student_age   = models.IntegerField()
    student_contend   = models.CharField(max_length=20)
    student_isDelete   = models.BooleanField(default=False)

    #关联外键  
    #on_delete=models.CASCADE
    #student_grade1 = models.ForeignKey("Grades")

